from .objects import ObjectsTable 
from .materials import MaterialsTable 
from .lights import LightsTable 
from .cameras import CamerasTable 
from .collections import CollectionsTable 
from .scene import SceneTable 
from .world import WorldTable 
from .meshes import MeshesTable 
from .images import ImagesTable 
from .modifiers import ModifiersTable 
from .constraints import ConstraintsTable 
from .custom_properties import CustomPropertiesTable 
from .texts import TextsTable 
from .curves import CurvesTable 
from .tables import TablesTable 

__all__ =[
,
,
,
,
,
,
,
,
,
,
,
,
,
,
,
]

